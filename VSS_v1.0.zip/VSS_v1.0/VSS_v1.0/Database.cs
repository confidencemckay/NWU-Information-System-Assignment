﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmDatabase : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";

        private void LoadTableData(string tableName)
        {
            string query = $"SELECT * FROM {tableName}";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dbDatabase.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public frmDatabase()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();
            this.Hide();
        }

        private void cmbDatabase_SelectedIndexChanged(object sender, EventArgs e)
        {

            //When combobox value changes
            switch (cmbDatabase.SelectedIndex)
            {
                case 0:
                    LoadTableData("tblAppointment");
                    break;

                case 1:
                    LoadTableData("tblAppointmentType");
                    break;

                case 2:
                    LoadTableData("tblPatient");
                    break;

                case 3:
                    LoadTableData("tblStaff");
                    break;

                default:
                    MessageBox.Show("Invalid table selection.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
            }

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();

            //Close Add Patient Form
            this.Close();
        }
    }
}
