﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmStaff : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";

        public frmStaff()
        {
            InitializeComponent();
        }

        public bool ValidateCredentials(string username, string password)
        {
            bool isValid = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"
                SELECT COUNT(*)
                FROM tblStaff
                WHERE FirstName + '.' + LastName LIKE @Username
                AND Password = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        int count = (int)command.ExecuteScalar();

                        if (count > 0)
                        {
                            isValid = true; // Credentials are valid

                            //Extracting staffID and Saving login to textfile
                            string qry = @"
                                SELECT StaffID
                                FROM tblStaff
                                WHERE FirstName + '.' + LastName = @Username
                                AND Password = @Password";

                            using (SqlCommand cmd = new SqlCommand(qry, connection))
                            {
                                cmd.Parameters.AddWithValue("@Username", username);
                                cmd.Parameters.AddWithValue("@Password", password);

                                try
                                {
                                    // Get StaffID
                                    using (SqlDataReader reader = cmd.ExecuteReader())
                                    {
                                        if (reader.Read())
                                        {
                                            GlobalData.StaffID = (int)reader["staffID"];
                                        }
                                    }


                                    
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error saving login to log file: " + ex.Message);
                                }
                            }
                        } //End If-Statement
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }

                }   //End Inner-Using Statement

            }   //End-Outerr Using Statement

            return isValid;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            //User Credentials Extraction
            string Username, Password;

            Username = txtUsername.Text;
            Password = txtPassword.Text;

            if (string.IsNullOrEmpty(Username) && string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Please enter username and password.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (string.IsNullOrEmpty(Username))
            {
                MessageBox.Show("Please enter a username.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Focus();
            }
            else if (string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Please enter a password.", "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsername.Focus();
            }
            else
            {

                bool isAuthenticated = ValidateCredentials(Username, Password);

                if (isAuthenticated)
                {

                    MessageBox.Show("Login successful. Welcome!", "Successful Login.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Proceed to Staff Home Form
                    // Create an instance of Staff
                    frmStaffHome StaffHome = new frmStaffHome();

                    // Show Staff as a new window
                    StaffHome.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Create instance of Welcome Page
            frmWelcomePage Welcome = new frmWelcomePage();

            //Show Welcome Page
            Welcome.Show();
            this.Close();
        }

    }

}
