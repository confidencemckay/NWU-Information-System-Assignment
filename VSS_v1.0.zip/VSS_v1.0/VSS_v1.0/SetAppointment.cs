﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using System.IO;

namespace VSS_v1._0
{
    public partial class frmSetAppointment : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        int selectedPatientID = -1;
        public frmSetAppointment()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home Page
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();

            //Set appointment form close
            this.Close();
        }

        private bool ValidateInputs()
        {
            // Check if each input component is filled/selected
            if (dtpAppDate.Value == DateTime.Today && cmbAppointmentTypeName.SelectedIndex != 5)
            {
                MessageBox.Show("Appointment for today can only be an emergency appointment.", "Emergency Appointment Only", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpAppDate.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cmbAppointmentTypeName.Text))
            {
                MessageBox.Show("Please select appointment type", "Appointment Type Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLastName.Focus();
                return false;
            }

            return true; //All inputs are valid
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                //Extracting user demographics input
                String FName, LName;
                DateTime AppDate = dtpAppDate.Value;
                FName = txtFirstName.Text;
                LName = txtLastName.Text;
                bool isPaid = false;

                //Categorising Appointment Types
                int AppointTypeID = (int)cmbAppointmentTypeName.SelectedValue;                             

                //Extract StaffID from GlobalData class
                int StaffID = GlobalData.StaffID;

                //Adding Appointment to Database
                if (MessageBox.Show("Confirm appointment for " + FName + " " + LName + " on " + AppDate.ToString(), "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    //Add Appointment Data to Database
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = @"INSERT INTO tblAppointment (AppointmentDate, StaffID, PatientID, AppointmentTypeID, isPaid)
                                        VALUES (@AppDate, @staffID, @patientID, @AppTypeID, @isPaid)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@AppDate", AppDate);
                            command.Parameters.AddWithValue("@staffID", StaffID);
                            command.Parameters.AddWithValue("@patientID", selectedPatientID);
                            command.Parameters.AddWithValue("@AppTypeID", AppointTypeID);
                            command.Parameters.AddWithValue("@isPaid", isPaid);

                            try
                            {
                                connection.Open();
                                int result = command.ExecuteNonQuery();

                                if (result > 0)
                                {
                                    MessageBox.Show("Appointment added successfully!");
                                }
                                else
                                {
                                    MessageBox.Show("Error: Appointment not added.");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message);
                            }
                        }
                    }

                    //Clearing input components
                    dtpAppDate.Value = DateTime.Today;
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    txtIDNo.Text = "";
                    txtEmail.Text = "";
                    txtPhoneNo.Text = "";
                    cmbGender.Text = "";
                    cmbAppointmentTypeName.SelectedIndex = -1;

                    //Disabling btnSubmit
                    btnSubmit.Enabled = false;

                    //Confirmation Messagebox
                    MessageBox.Show("Appointment scheduled successfully.", "Appointment Scheduling Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //Cancellation confirmation for user
                    MessageBox.Show("Appointment scheduling cancelled successfully.", "Appointment Scheduling Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void frmSetAppointment_Load(object sender, EventArgs e)
        {
            //Loading all Patients onto Patients Combobox
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT patientID, FirstName + ' ' + LastName AS 'Patient Name' FROM tblPatient";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        DataTable dt = new DataTable();

                        using (SqlDataAdapter da = new SqlDataAdapter(command))
                        {

                            da.Fill(dt);
                        }

                        if (dt.Rows.Count > 0)
                        {
                            cmbPatient.DisplayMember = "Patient Name";  
                            cmbPatient.ValueMember = "patientID";   
                            cmbPatient.DataSource = dt; 
                        }
                        else
                        {
                            MessageBox.Show("No patients found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    } //End Try-Catch statement
                } // End Inner-Using Statement
            }  // End Outer-Using statement

            //Populating cmbAppointmentTypeName
            cmbAppointmentTypeName.Items.Clear();

            string qry = "SELECT AppointmentTypeID, AppointmentTypeName FROM tblAppointmentType";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(qry, connection))
                {
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);

                            cmbAppointmentTypeName.DisplayMember = "AppointmentTypeName"; 
                            cmbAppointmentTypeName.ValueMember = "AppointmentTypeID";     
                            cmbAppointmentTypeName.DataSource = dt;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading appointment types: " + ex.Message);
                    }
                }
            }

        }

       private void LoadPatientDetails(int patientID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM tblPatient WHERE patientID = @PatientID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PatientID", patientID);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtFirstName.Text = reader["FirstName"].ToString();
                                txtLastName.Text = reader["LastName"].ToString();
                                txtIDNo.Text = reader["IDNumber"].ToString();  
                                cmbGender.Text = reader["Gender"].ToString();
                                txtEmail.Text = reader["Email"].ToString();
                                txtPhoneNo.Text = reader["PhoneNumber"].ToString();

                                //Enable Submit button
                                btnSubmit.Enabled = true;
                            }
                            else
                            {
                                MessageBox.Show("Patient not found.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }


        private void cmbPatient_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Extract the selected PatientID and save it to the global variable
            if (cmbPatient.SelectedIndex != -1)
            {
                selectedPatientID = (int)cmbPatient.SelectedValue;

                LoadPatientDetails(selectedPatientID);
            }
           
        }
    }
}
