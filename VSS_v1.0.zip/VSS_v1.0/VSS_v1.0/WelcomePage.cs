﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmWelcomePage : Form
    {
        public frmWelcomePage()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close Application
            Application.Exit();
        }


        private void btnStaff_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff
            frmStaff Staff = new frmStaff();

            // Show Staff as a new window
            Staff.Show();
            this.Hide();
        }
    }
}
