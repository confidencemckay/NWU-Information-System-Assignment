﻿namespace VSS_v1._0
{
    partial class frmStaffHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStaffHome));
            this.pnlStaffHome = new System.Windows.Forms.Panel();
            this.btnAddStaff = new System.Windows.Forms.Button();
            this.btnAddPatients = new System.Windows.Forms.Button();
            this.btnSetAppointment = new System.Windows.Forms.Button();
            this.mnuMenu = new System.Windows.Forms.MenuStrip();
            this.manageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.appointmentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.appointmentTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddAppType = new System.Windows.Forms.Button();
            this.pnlStaffHome.SuspendLayout();
            this.mnuMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlStaffHome
            // 
            this.pnlStaffHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlStaffHome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStaffHome.Controls.Add(this.btnAddAppType);
            this.pnlStaffHome.Controls.Add(this.btnAddStaff);
            this.pnlStaffHome.Controls.Add(this.btnAddPatients);
            this.pnlStaffHome.Controls.Add(this.btnSetAppointment);
            this.pnlStaffHome.Location = new System.Drawing.Point(572, 342);
            this.pnlStaffHome.Name = "pnlStaffHome";
            this.pnlStaffHome.Size = new System.Drawing.Size(725, 130);
            this.pnlStaffHome.TabIndex = 3;
            // 
            // btnAddStaff
            // 
            this.btnAddStaff.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStaff.Location = new System.Drawing.Point(354, 55);
            this.btnAddStaff.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddStaff.Name = "btnAddStaff";
            this.btnAddStaff.Size = new System.Drawing.Size(130, 30);
            this.btnAddStaff.TabIndex = 5;
            this.btnAddStaff.Text = "Add &Staff";
            this.btnAddStaff.UseVisualStyleBackColor = true;
            this.btnAddStaff.Click += new System.EventHandler(this.btnAddStaff_Click);
            // 
            // btnAddPatients
            // 
            this.btnAddPatients.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPatients.Location = new System.Drawing.Point(200, 55);
            this.btnAddPatients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddPatients.Name = "btnAddPatients";
            this.btnAddPatients.Size = new System.Drawing.Size(130, 30);
            this.btnAddPatients.TabIndex = 4;
            this.btnAddPatients.Text = "Add &Patient";
            this.btnAddPatients.UseVisualStyleBackColor = true;
            this.btnAddPatients.Click += new System.EventHandler(this.btnAddPatients_Click);
            // 
            // btnSetAppointment
            // 
            this.btnSetAppointment.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetAppointment.Location = new System.Drawing.Point(45, 55);
            this.btnSetAppointment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSetAppointment.Name = "btnSetAppointment";
            this.btnSetAppointment.Size = new System.Drawing.Size(130, 30);
            this.btnSetAppointment.TabIndex = 3;
            this.btnSetAppointment.Text = "Set &Appointment";
            this.btnSetAppointment.UseVisualStyleBackColor = true;
            this.btnSetAppointment.Click += new System.EventHandler(this.btnSetAppointment_Click);
            // 
            // mnuMenu
            // 
            this.mnuMenu.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageToolStripMenuItem,
            this.databaseToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.mnuMenu.Location = new System.Drawing.Point(0, 0);
            this.mnuMenu.Name = "mnuMenu";
            this.mnuMenu.Size = new System.Drawing.Size(1582, 28);
            this.mnuMenu.TabIndex = 4;
            this.mnuMenu.Text = "menuStrip1";
            // 
            // manageToolStripMenuItem
            // 
            this.manageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appointmentsToolStripMenuItem,
            this.patientsToolStripMenuItem,
            this.appointmentTypeToolStripMenuItem,
            this.staffToolStripMenuItem});
            this.manageToolStripMenuItem.Name = "manageToolStripMenuItem";
            this.manageToolStripMenuItem.Size = new System.Drawing.Size(69, 24);
            this.manageToolStripMenuItem.Text = "Manage";
            // 
            // appointmentsToolStripMenuItem
            // 
            this.appointmentsToolStripMenuItem.Name = "appointmentsToolStripMenuItem";
            this.appointmentsToolStripMenuItem.Size = new System.Drawing.Size(187, 24);
            this.appointmentsToolStripMenuItem.Text = "Appointments";
            this.appointmentsToolStripMenuItem.Click += new System.EventHandler(this.appointmentsToolStripMenuItem_Click);
            // 
            // patientsToolStripMenuItem
            // 
            this.patientsToolStripMenuItem.Name = "patientsToolStripMenuItem";
            this.patientsToolStripMenuItem.Size = new System.Drawing.Size(187, 24);
            this.patientsToolStripMenuItem.Text = "Patients";
            this.patientsToolStripMenuItem.Click += new System.EventHandler(this.patientsToolStripMenuItem_Click);
            // 
            // appointmentTypeToolStripMenuItem
            // 
            this.appointmentTypeToolStripMenuItem.Name = "appointmentTypeToolStripMenuItem";
            this.appointmentTypeToolStripMenuItem.Size = new System.Drawing.Size(187, 24);
            this.appointmentTypeToolStripMenuItem.Text = "Appointment Type";
            this.appointmentTypeToolStripMenuItem.Click += new System.EventHandler(this.appointmentTypeToolStripMenuItem_Click);
            // 
            // staffToolStripMenuItem
            // 
            this.staffToolStripMenuItem.Name = "staffToolStripMenuItem";
            this.staffToolStripMenuItem.Size = new System.Drawing.Size(187, 24);
            this.staffToolStripMenuItem.Text = "Staff";
            this.staffToolStripMenuItem.Click += new System.EventHandler(this.staffToolStripMenuItem_Click);
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.databaseToolStripMenuItem.Text = "&Database";
            this.databaseToolStripMenuItem.Click += new System.EventHandler(this.databaseToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.reportsToolStripMenuItem.Text = "&Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.logOutToolStripMenuItem.Text = "&LogOut";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // btnAddAppType
            // 
            this.btnAddAppType.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddAppType.Location = new System.Drawing.Point(507, 55);
            this.btnAddAppType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddAppType.Name = "btnAddAppType";
            this.btnAddAppType.Size = new System.Drawing.Size(168, 30);
            this.btnAddAppType.TabIndex = 6;
            this.btnAddAppType.Text = "Add Appointment &Type";
            this.btnAddAppType.UseVisualStyleBackColor = true;
            this.btnAddAppType.Click += new System.EventHandler(this.btnAddAppType_Click);
            // 
            // frmStaffHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VSS_v1._0.Properties.Resources.marcelo_leal_6pcGTJDuf6M_unsplash;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1582, 811);
            this.Controls.Add(this.pnlStaffHome);
            this.Controls.Add(this.mnuMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnuMenu;
            this.Name = "frmStaffHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staff Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlStaffHome.ResumeLayout(false);
            this.mnuMenu.ResumeLayout(false);
            this.mnuMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlStaffHome;
        private System.Windows.Forms.Button btnAddStaff;
        private System.Windows.Forms.Button btnAddPatients;
        private System.Windows.Forms.Button btnSetAppointment;
        private System.Windows.Forms.MenuStrip mnuMenu;
        private System.Windows.Forms.ToolStripMenuItem manageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem databaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem appointmentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem appointmentTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffToolStripMenuItem;
        private System.Windows.Forms.Button btnAddAppType;
    }
}