﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmAddStaff : Form
    {
        public string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmAddStaff()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();

            //Close Add Staff Form
            this.Close();
        }

        private bool ValidateInputs()
        {
            // Check if each input component is filled/selected
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("Please enter the first name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFirstName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("Please enter the last name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLastName.Focus();
                return false;
            }

            if (cmbGender.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a gender.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbGender.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter the address.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtID.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPhoneNo.Text))
            {
                MessageBox.Show("Please enter the phone number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPhoneNo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Please enter the email address.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please enter the email address.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return false;
            }

            return true; // All inputs are valid
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInputs()) //Input Validation
            {
                //Patient Demographics Extraction
                string FName, LName, IDNo, Email, PhoneNo, Gender, Password;
                FName = txtFirstName.Text;
                LName = txtLastName.Text;
                IDNo = txtID.Text;
                Email = txtEmail.Text;
                PhoneNo = txtPhoneNo.Text;
                Gender = cmbGender.Text;
                Password = txtPassword.Text;

                if (MessageBox.Show("Confirm adding " + FName + " " + LName + " to staff database. ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string query = "INSERT INTO tblStaff (FirstName, LastName, IDNumber, Gender, PhoneNumber, Email, Password) " +
                               "VALUES (@FirstName, @LastName, @IDNumber, @Gender, @PhoneNumber, @Email, @Password)";

                    try
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {
                                // Add parameters to avoid SQL injection
                                cmd.Parameters.AddWithValue("@FirstName", FName);
                                cmd.Parameters.AddWithValue("@LastName", LName);
                                cmd.Parameters.AddWithValue("@IDNumber", IDNo);
                                cmd.Parameters.AddWithValue("@Gender", Gender);
                                cmd.Parameters.AddWithValue("@Email", Email);
                                cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNo);
                                cmd.Parameters.AddWithValue("@Password", Password);

                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    //Clear input components
                                    txtFirstName.Text = "";
                                    txtLastName.Text = "";
                                    txtID.Text = "";
                                    txtEmail.Text = "";
                                    txtPhoneNo.Text = "";
                                    cmbGender.SelectedIndex = -1;
                                    txtPassword.Text = "";

                                    //Confirmation Message
                                    MessageBox.Show("Staff member " + FName + " " + LName + " added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Failed to add staff.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    //Cancellation confirmation for user
                    MessageBox.Show("Staff addition cancelled successfully.", "Add Staff Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
    
}
