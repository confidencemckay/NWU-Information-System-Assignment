﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmManageAppointment : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmManageAppointment()
        {
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Enable Input Controls for change
            txtStaffID.Enabled = true;
            txtPatientID.Enabled = true;
            txtAppTypeID.Enabled = true;
            dtpAppDate.Enabled = true;
            chkisPaid.Enabled = true;

            MessageBox.Show("Update enabled. You may edit the appointment record. Please don't forget to save changes.", "Editing enabled", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPatientID.Text))
            {
                MessageBox.Show("PatientID cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtStaffID.Text))
            {
                MessageBox.Show("StaffID cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (dtpAppDate.Value.Date <= DateTime.Today)
            {
                MessageBox.Show("The appointment date cannot be today or in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (int.Parse(txtAppTypeID.Text) > 5 || int.Parse(txtAppTypeID.Text) < 0)
            {
                MessageBox.Show("The AppointmentTypeID date cannot be higher than 5 or less than 1.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true; // Return true if all inputs are valid
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                if (MessageBox.Show("Do you want to save the changes?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string query = "UPDATE tblAppointment SET PatientID = @PatientID, StaffID = @StaffID, AppointmentDate = @AppointmentDate, AppointmentTypeID = @AppointmentTypeID, isPaid = @IsPaid WHERE AppointmentID = @AppointmentID";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@PatientID", txtPatientID.Text);
                            cmd.Parameters.AddWithValue("@StaffID", txtStaffID.Text);
                            cmd.Parameters.AddWithValue("@AppointmentDate", dtpAppDate.Value);
                            cmd.Parameters.AddWithValue("@AppointmentTypeID", txtAppTypeID.Text);
                            cmd.Parameters.AddWithValue("@IsPaid", chkisPaid.Checked);
                            cmd.Parameters.AddWithValue("@AppointmentID", txtAppID.Text); 

                            try
                            {
                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Appointment record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    //Disabling Input components for editing
                                    txtPatientID.Enabled = false;
                                    txtStaffID.Enabled = false;
                                    dtpAppDate.Enabled = false;
                                    txtAppTypeID.Enabled = false;
                                    chkisPaid.Enabled = false;
                                    txtAppID.Enabled = false;

                                    // Reloading Database
                                    string qry = "SELECT * FROM tblAppointment ORDER BY AppointmentDate DESC";

                                    using (SqlConnection con = new SqlConnection(connectionString))
                                    {
                                        try
                                        {
                                            SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, con);
                                            DataTable dataTable = new DataTable();
                                            dataAdapter.Fill(dataTable);

                                            dbAppointments.DataSource = dataTable;
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("No records were updated.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            } //End-Validate Inputs If Statements

        }

        private void frmManageAppointment_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM tblAppointment ORDER BY AppointmentDate DESC";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dbAppointments.DataSource = dataTable; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            //Delete function only for Admin
            if (GlobalData.StaffID != 1)
                btnDelete.Enabled = false;
            
        }

        private void dbAppointments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Load selected record into input components
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbAppointments.Rows[e.RowIndex];

                txtAppID.Text = row.Cells["AppointmentID"].Value.ToString();
                txtPatientID.Text = row.Cells["PatientID"].Value.ToString(); 
                txtStaffID.Text = row.Cells["StaffID"].Value.ToString();  
                dtpAppDate.Value = Convert.ToDateTime(row.Cells["AppointmentDate"].Value);
                txtAppTypeID.Text = row.Cells["AppointmentTypeID"].Value.ToString();
                bool isPaid = Convert.ToBoolean(row.Cells["isPaid"].Value);
                chkisPaid.Checked = isPaid;
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Staff Home as a new window
            Home.Show();

            //Close Manage Appointment Type Form
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Extract selected AppointmentID 
            if (txtAppID.Text == null)
            {
                MessageBox.Show("Please select a appointment type to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedAppointID = int.Parse(txtAppID.Text);

            //Confirm deletion
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this appointment?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                string query = "DELETE FROM tblAppointment WHERE AppointmentID = @AppointmentID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AppointmentTypeID", selectedAppointID);

                        try
                        {
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Appointment deleted successfully.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Reloading database
                                string qry = "SELECT * FROM tblAppointment";

                                using (SqlConnection cnn = new SqlConnection(connectionString))
                                {
                                    try
                                    {
                                        SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, cnn);
                                        DataTable dataTable = new DataTable();
                                        dataAdapter.Fill(dataTable);

                                        dbAppointments.DataSource = dataTable;
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting appointment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
