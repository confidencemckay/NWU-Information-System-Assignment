﻿namespace VSS_v1._0
{
    partial class frmAddAppointmentType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddAppointmentType));
            this.pnlPatientDemographics = new System.Windows.Forms.Panel();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtAppTypeName = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblAppTypeName = new System.Windows.Forms.Label();
            this.lblInstruct = new System.Windows.Forms.Label();
            this.btnHome = new System.Windows.Forms.Button();
            this.pnlPatientDemographics.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPatientDemographics
            // 
            this.pnlPatientDemographics.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPatientDemographics.Controls.Add(this.btnAdd);
            this.pnlPatientDemographics.Controls.Add(this.txtDescription);
            this.pnlPatientDemographics.Controls.Add(this.txtAppTypeName);
            this.pnlPatientDemographics.Controls.Add(this.lblDescription);
            this.pnlPatientDemographics.Controls.Add(this.lblAppTypeName);
            this.pnlPatientDemographics.Controls.Add(this.lblInstruct);
            this.pnlPatientDemographics.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlPatientDemographics.Location = new System.Drawing.Point(310, 175);
            this.pnlPatientDemographics.Name = "pnlPatientDemographics";
            this.pnlPatientDemographics.Size = new System.Drawing.Size(981, 259);
            this.pnlPatientDemographics.TabIndex = 1;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(801, 207);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(159, 30);
            this.btnAdd.TabIndex = 22;
            this.btnAdd.Text = "&Add Appointment Type";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(345, 131);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(230, 26);
            this.txtDescription.TabIndex = 17;
            // 
            // txtAppTypeName
            // 
            this.txtAppTypeName.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAppTypeName.Location = new System.Drawing.Point(345, 86);
            this.txtAppTypeName.Name = "txtAppTypeName";
            this.txtAppTypeName.Size = new System.Drawing.Size(230, 26);
            this.txtAppTypeName.TabIndex = 16;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(178, 137);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(76, 20);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Description";
            // 
            // lblAppTypeName
            // 
            this.lblAppTypeName.AutoSize = true;
            this.lblAppTypeName.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppTypeName.Location = new System.Drawing.Point(178, 89);
            this.lblAppTypeName.Name = "lblAppTypeName";
            this.lblAppTypeName.Size = new System.Drawing.Size(157, 20);
            this.lblAppTypeName.TabIndex = 1;
            this.lblAppTypeName.Text = "Appointment Type Name";
            // 
            // lblInstruct
            // 
            this.lblInstruct.AutoSize = true;
            this.lblInstruct.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruct.Location = new System.Drawing.Point(17, 23);
            this.lblInstruct.Name = "lblInstruct";
            this.lblInstruct.Size = new System.Drawing.Size(198, 20);
            this.lblInstruct.TabIndex = 0;
            this.lblInstruct.Text = "Please enter Appointment Type";
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(1508, 770);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(80, 30);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "&Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // frmAddAppointmentType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VSS_v1._0.Properties.Resources.pexels_pixabay_40568;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1600, 812);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.pnlPatientDemographics);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmAddAppointmentType";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Appointment Type";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlPatientDemographics.ResumeLayout(false);
            this.pnlPatientDemographics.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPatientDemographics;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtAppTypeName;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblAppTypeName;
        private System.Windows.Forms.Label lblInstruct;
        private System.Windows.Forms.Button btnHome;
    }
}