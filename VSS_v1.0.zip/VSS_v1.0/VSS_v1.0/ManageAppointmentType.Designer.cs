﻿namespace VSS_v1._0
{
    partial class frmManageAppointmentType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManageAppointmentType));
            this.btnHome = new System.Windows.Forms.Button();
            this.pnlManageAppointment = new System.Windows.Forms.Panel();
            this.cmbAppointmentTypeName = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtAppointTypeID = new System.Windows.Forms.TextBox();
            this.lblPatientID = new System.Windows.Forms.Label();
            this.lblAppointmentTypeName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.dbManageAppType = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlManageAppointment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbManageAppType)).BeginInit();
            this.SuspendLayout();
            // 
            // btnHome
            // 
            this.btnHome.Location = new System.Drawing.Point(1461, 771);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(100, 30);
            this.btnHome.TabIndex = 21;
            this.btnHome.Text = "&Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // pnlManageAppointment
            // 
            this.pnlManageAppointment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlManageAppointment.Controls.Add(this.btnDelete);
            this.pnlManageAppointment.Controls.Add(this.cmbAppointmentTypeName);
            this.pnlManageAppointment.Controls.Add(this.btnSave);
            this.pnlManageAppointment.Controls.Add(this.btnUpdate);
            this.pnlManageAppointment.Controls.Add(this.txtDescription);
            this.pnlManageAppointment.Controls.Add(this.txtAppointTypeID);
            this.pnlManageAppointment.Controls.Add(this.lblPatientID);
            this.pnlManageAppointment.Controls.Add(this.lblAppointmentTypeName);
            this.pnlManageAppointment.Controls.Add(this.lblID);
            this.pnlManageAppointment.Controls.Add(this.lblDescription);
            this.pnlManageAppointment.Controls.Add(this.dbManageAppType);
            this.pnlManageAppointment.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlManageAppointment.Location = new System.Drawing.Point(205, 90);
            this.pnlManageAppointment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlManageAppointment.Name = "pnlManageAppointment";
            this.pnlManageAppointment.Size = new System.Drawing.Size(1252, 627);
            this.pnlManageAppointment.TabIndex = 20;
            // 
            // cmbAppointmentTypeName
            // 
            this.cmbAppointmentTypeName.Enabled = false;
            this.cmbAppointmentTypeName.FormattingEnabled = true;
            this.cmbAppointmentTypeName.Items.AddRange(new object[] {
            "General",
            "Specialist",
            "Follow-Up",
            "Diagnosis",
            "Emergency",
            "Counseling"});
            this.cmbAppointmentTypeName.Location = new System.Drawing.Point(251, 405);
            this.cmbAppointmentTypeName.Name = "cmbAppointmentTypeName";
            this.cmbAppointmentTypeName.Size = new System.Drawing.Size(200, 28);
            this.cmbAppointmentTypeName.TabIndex = 22;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(1135, 572);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(1029, 572);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 30);
            this.btnUpdate.TabIndex = 15;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Enabled = false;
            this.txtDescription.Location = new System.Drawing.Point(251, 439);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(200, 26);
            this.txtDescription.TabIndex = 13;
            // 
            // txtAppointTypeID
            // 
            this.txtAppointTypeID.Enabled = false;
            this.txtAppointTypeID.Location = new System.Drawing.Point(251, 373);
            this.txtAppointTypeID.Name = "txtAppointTypeID";
            this.txtAppointTypeID.Size = new System.Drawing.Size(200, 26);
            this.txtAppointTypeID.TabIndex = 12;
            // 
            // lblPatientID
            // 
            this.lblPatientID.AutoSize = true;
            this.lblPatientID.Location = new System.Drawing.Point(30, 376);
            this.lblPatientID.Name = "lblPatientID";
            this.lblPatientID.Size = new System.Drawing.Size(134, 20);
            this.lblPatientID.TabIndex = 7;
            this.lblPatientID.Text = "Appointment Type ID";
            // 
            // lblAppointmentTypeName
            // 
            this.lblAppointmentTypeName.AutoSize = true;
            this.lblAppointmentTypeName.Location = new System.Drawing.Point(30, 408);
            this.lblAppointmentTypeName.Name = "lblAppointmentTypeName";
            this.lblAppointmentTypeName.Size = new System.Drawing.Size(118, 20);
            this.lblAppointmentTypeName.TabIndex = 6;
            this.lblAppointmentTypeName.Text = "Appointment Type";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(30, 416);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 20);
            this.lblID.TabIndex = 5;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(30, 442);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(76, 20);
            this.lblDescription.TabIndex = 3;
            this.lblDescription.Text = "Description";
            // 
            // dbManageAppType
            // 
            this.dbManageAppType.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbManageAppType.Location = new System.Drawing.Point(34, 21);
            this.dbManageAppType.Name = "dbManageAppType";
            this.dbManageAppType.Size = new System.Drawing.Size(1201, 330);
            this.dbManageAppType.TabIndex = 2;
            this.dbManageAppType.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dbManageApp_CellClick);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(916, 572);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 22;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmManageAppointmentType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VSS_v1._0.Properties.Resources.pexels_cristian_rojas_8459996;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1573, 813);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.pnlManageAppointment);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmManageAppointmentType";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage Appointment Type";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmManageAppointmentType_Load);
            this.pnlManageAppointment.ResumeLayout(false);
            this.pnlManageAppointment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbManageAppType)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel pnlManageAppointment;
        private System.Windows.Forms.ComboBox cmbAppointmentTypeName;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtAppointTypeID;
        private System.Windows.Forms.Label lblPatientID;
        private System.Windows.Forms.Label lblAppointmentTypeName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.DataGridView dbManageAppType;
        private System.Windows.Forms.Button btnDelete;
    }
}