﻿namespace VSS_v1._0
{
    partial class frmManageAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManageAppointment));
            this.pnlManageAppointment = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.dtpAppDate = new System.Windows.Forms.DateTimePicker();
            this.txtAppTypeID = new System.Windows.Forms.TextBox();
            this.txtPatientID = new System.Windows.Forms.TextBox();
            this.txtStaffID = new System.Windows.Forms.TextBox();
            this.txtAppID = new System.Windows.Forms.TextBox();
            this.chkisPaid = new System.Windows.Forms.CheckBox();
            this.lblAppointmentTypeID = new System.Windows.Forms.Label();
            this.lblPatientID = new System.Windows.Forms.Label();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblAppID = new System.Windows.Forms.Label();
            this.dbAppointments = new System.Windows.Forms.DataGridView();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlManageAppointment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlManageAppointment
            // 
            this.pnlManageAppointment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlManageAppointment.Controls.Add(this.btnDelete);
            this.pnlManageAppointment.Controls.Add(this.btnSave);
            this.pnlManageAppointment.Controls.Add(this.btnUpdate);
            this.pnlManageAppointment.Controls.Add(this.dtpAppDate);
            this.pnlManageAppointment.Controls.Add(this.txtAppTypeID);
            this.pnlManageAppointment.Controls.Add(this.txtPatientID);
            this.pnlManageAppointment.Controls.Add(this.txtStaffID);
            this.pnlManageAppointment.Controls.Add(this.txtAppID);
            this.pnlManageAppointment.Controls.Add(this.chkisPaid);
            this.pnlManageAppointment.Controls.Add(this.lblAppointmentTypeID);
            this.pnlManageAppointment.Controls.Add(this.lblPatientID);
            this.pnlManageAppointment.Controls.Add(this.lblStaffID);
            this.pnlManageAppointment.Controls.Add(this.lblID);
            this.pnlManageAppointment.Controls.Add(this.lblDate);
            this.pnlManageAppointment.Controls.Add(this.lblAppID);
            this.pnlManageAppointment.Controls.Add(this.dbAppointments);
            this.pnlManageAppointment.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlManageAppointment.Location = new System.Drawing.Point(205, 90);
            this.pnlManageAppointment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlManageAppointment.Name = "pnlManageAppointment";
            this.pnlManageAppointment.Size = new System.Drawing.Size(1341, 627);
            this.pnlManageAppointment.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(1205, 572);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(1099, 572);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 30);
            this.btnUpdate.TabIndex = 15;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // dtpAppDate
            // 
            this.dtpAppDate.Enabled = false;
            this.dtpAppDate.Location = new System.Drawing.Point(251, 501);
            this.dtpAppDate.Name = "dtpAppDate";
            this.dtpAppDate.Size = new System.Drawing.Size(220, 26);
            this.dtpAppDate.TabIndex = 14;
            // 
            // txtAppTypeID
            // 
            this.txtAppTypeID.Enabled = false;
            this.txtAppTypeID.Location = new System.Drawing.Point(251, 469);
            this.txtAppTypeID.Name = "txtAppTypeID";
            this.txtAppTypeID.Size = new System.Drawing.Size(150, 26);
            this.txtAppTypeID.TabIndex = 13;
            // 
            // txtPatientID
            // 
            this.txtPatientID.Enabled = false;
            this.txtPatientID.Location = new System.Drawing.Point(251, 437);
            this.txtPatientID.Name = "txtPatientID";
            this.txtPatientID.Size = new System.Drawing.Size(150, 26);
            this.txtPatientID.TabIndex = 12;
            // 
            // txtStaffID
            // 
            this.txtStaffID.Enabled = false;
            this.txtStaffID.Location = new System.Drawing.Point(251, 405);
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Size = new System.Drawing.Size(150, 26);
            this.txtStaffID.TabIndex = 11;
            // 
            // txtAppID
            // 
            this.txtAppID.Enabled = false;
            this.txtAppID.Location = new System.Drawing.Point(251, 373);
            this.txtAppID.Name = "txtAppID";
            this.txtAppID.Size = new System.Drawing.Size(150, 26);
            this.txtAppID.TabIndex = 10;
            // 
            // chkisPaid
            // 
            this.chkisPaid.AutoSize = true;
            this.chkisPaid.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkisPaid.Enabled = false;
            this.chkisPaid.Location = new System.Drawing.Point(34, 542);
            this.chkisPaid.Name = "chkisPaid";
            this.chkisPaid.Size = new System.Drawing.Size(69, 24);
            this.chkisPaid.TabIndex = 9;
            this.chkisPaid.Text = "is Paid";
            this.chkisPaid.UseVisualStyleBackColor = true;
            // 
            // lblAppointmentTypeID
            // 
            this.lblAppointmentTypeID.AutoSize = true;
            this.lblAppointmentTypeID.Location = new System.Drawing.Point(30, 472);
            this.lblAppointmentTypeID.Name = "lblAppointmentTypeID";
            this.lblAppointmentTypeID.Size = new System.Drawing.Size(134, 20);
            this.lblAppointmentTypeID.TabIndex = 8;
            this.lblAppointmentTypeID.Text = "Appointment Type ID";
            // 
            // lblPatientID
            // 
            this.lblPatientID.AutoSize = true;
            this.lblPatientID.Location = new System.Drawing.Point(30, 440);
            this.lblPatientID.Name = "lblPatientID";
            this.lblPatientID.Size = new System.Drawing.Size(65, 20);
            this.lblPatientID.TabIndex = 7;
            this.lblPatientID.Text = "Patient ID";
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Location = new System.Drawing.Point(30, 408);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(50, 20);
            this.lblStaffID.TabIndex = 6;
            this.lblStaffID.Text = "Staff ID";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(30, 416);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 20);
            this.lblID.TabIndex = 5;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(30, 507);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(115, 20);
            this.lblDate.TabIndex = 4;
            this.lblDate.Text = "Appointment Date";
            // 
            // lblAppID
            // 
            this.lblAppID.AutoSize = true;
            this.lblAppID.Location = new System.Drawing.Point(30, 376);
            this.lblAppID.Name = "lblAppID";
            this.lblAppID.Size = new System.Drawing.Size(100, 20);
            this.lblAppID.TabIndex = 3;
            this.lblAppID.Text = "Appointment ID";
            // 
            // dbAppointments
            // 
            this.dbAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbAppointments.Location = new System.Drawing.Point(34, 28);
            this.dbAppointments.Name = "dbAppointments";
            this.dbAppointments.Size = new System.Drawing.Size(1271, 326);
            this.dbAppointments.TabIndex = 2;
            this.dbAppointments.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dbAppointments_CellClick);
            // 
            // btnHome
            // 
            this.btnHome.Location = new System.Drawing.Point(1472, 769);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(100, 30);
            this.btnHome.TabIndex = 17;
            this.btnHome.Text = "&Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(993, 572);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 18;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmManageAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VSS_v1._0.Properties.Resources.pexels_rdne_6129141;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1584, 811);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.pnlManageAppointment);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmManageAppointment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage Appointment";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmManageAppointment_Load);
            this.pnlManageAppointment.ResumeLayout(false);
            this.pnlManageAppointment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbAppointments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlManageAppointment;
        private System.Windows.Forms.DataGridView dbAppointments;
        private System.Windows.Forms.Label lblPatientID;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblAppID;
        private System.Windows.Forms.Label lblAppointmentTypeID;
        private System.Windows.Forms.TextBox txtAppTypeID;
        private System.Windows.Forms.TextBox txtPatientID;
        private System.Windows.Forms.TextBox txtStaffID;
        private System.Windows.Forms.TextBox txtAppID;
        private System.Windows.Forms.CheckBox chkisPaid;
        private System.Windows.Forms.DateTimePicker dtpAppDate;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
    }
}