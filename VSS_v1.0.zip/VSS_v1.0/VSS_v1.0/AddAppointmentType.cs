﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace VSS_v1._0
{
    public partial class frmAddAppointmentType : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmAddAppointmentType()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtAppTypeName.Text != null)
            {
                string AppTypeName = txtAppTypeName.Text;
                string Description = txtDescription.Text;

                if (MessageBox.Show("Confirm adding " + AppTypeName + " to Appointment Type database. ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string qry = "INSERT INTO tblAppointmentType (AppointmentTypeName, Description) VALUES (@AppointmentTypeName, @Description)";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(qry, connection))
                        {
                            // Add parameters to the SQL command
                            command.Parameters.AddWithValue("@AppointmentTypeName", AppTypeName);
                            command.Parameters.AddWithValue("@Description", Description);

                            try
                            {
                                connection.Open();
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Appointment Type added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    //Clear input components
                                    txtAppTypeName.Clear();
                                    txtDescription.Clear();

                                }
                                else
                                {
                                    MessageBox.Show("Failed to add Appointment Type. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error adding Appointment Type: " + ex.Message);
                            }
                        }
                    }
                } else
                {
                    MessageBox.Show("Appointment Type addition cancelled successfully.", "Add Appointment Type Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            } else
            {
                MessageBox.Show("Please enter an Appointment Type Name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAppTypeName.Focus();
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();
            this.Hide();
        }
    }
}
