﻿// CMPG223 - Group 46 - Confidence
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSS_v1._0
{
    public static class GlobalData
    {
        public static int StaffID { get; set; }
    }
}
