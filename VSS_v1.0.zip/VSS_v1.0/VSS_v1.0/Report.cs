﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmReport : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmReport()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Home as a new window
            Home.Show();
            this.Hide();
        }

        private void GenerateSummaryReport()
        {
            string reportTitle = "Overall Summary Report";
            bool filterByDate = chkFilterDate.Checked;
            DateTime startDate = dtpStart.Value.Date;
            DateTime endDate = dtpEnd.Value.Date;

            if (filterByDate)
            {
                reportTitle = $"Summary Report from {startDate.ToShortDateString()} to {endDate.ToShortDateString()}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    StringBuilder report = new StringBuilder();
                    report.AppendLine(reportTitle);
                    report.AppendLine(new string('-', 50));

                    // Total Patients
                    string totalPatientsQuery = "SELECT COUNT(*) FROM tblPatient";
                    int totalPatients = ExecuteScalarQuery(connection, totalPatientsQuery);
                    report.AppendLine($"Total Patients: {totalPatients}");

                    // Total Staff
                    string totalStaffQuery = "SELECT COUNT(*) FROM tblStaff";
                    int totalStaff = ExecuteScalarQuery(connection, totalStaffQuery);
                    report.AppendLine($"Total Staff: {totalStaff}");

                    // Total Appointments
                    string totalAppointmentsQuery = "SELECT COUNT(*) FROM tblAppointment";
                    if (filterByDate)
                    {
                        totalAppointmentsQuery += " WHERE AppointmentDate BETWEEN @startDate AND @endDate";
                    }
                    int totalAppointments = ExecuteScalarQuery(connection, totalAppointmentsQuery, startDate, endDate);
                    report.AppendLine($"Total Appointments: {totalAppointments}");

                    // Top 10 Most Frequent Patients
                    string topPatientsQuery = @"
                SELECT TOP 10 p.FirstName + ' ' + p.LastName AS PatientName, COUNT(a.AppointmentID) AS AppointmentCount
                FROM tblAppointment a
                INNER JOIN tblPatient p ON a.PatientID = p.PatientID
                GROUP BY p.FirstName, p.LastName
                ORDER BY AppointmentCount DESC";
                    report.AppendLine("\nTop 10 Most Frequent Patients:");
                    AppendQueryResults(report, connection, topPatientsQuery, filterByDate, startDate, endDate);

                    // Paid vs Unpaid Appointments
                    string paidQuery = "SELECT COUNT(*) FROM tblAppointment WHERE isPaid = 1";
                    string unpaidQuery = "SELECT COUNT(*) FROM tblAppointment WHERE isPaid = 0";
                    if (filterByDate)
                    {
                        paidQuery += " AND AppointmentDate BETWEEN @startDate AND @endDate";
                        unpaidQuery += " AND AppointmentDate BETWEEN @startDate AND @endDate";
                    }
                    int paidAppointments = ExecuteScalarQuery(connection, paidQuery, startDate, endDate);
                    int unpaidAppointments = ExecuteScalarQuery(connection, unpaidQuery, startDate, endDate);
                    report.AppendLine($"\nPaid Appointments: {paidAppointments}");
                    report.AppendLine($"Unpaid Appointments: {unpaidAppointments}");

                    // Stats for Appointment Types
                    string appointmentTypesQuery = @"
                SELECT at.AppointmentTypeName, COUNT(a.AppointmentID) AS AppointmentCount
                FROM tblAppointmentType at
                LEFT JOIN tblAppointment a ON at.AppointmentTypeID = a.AppointmentTypeID";
                    if (filterByDate)
                    {
                        appointmentTypesQuery += " WHERE a.AppointmentDate BETWEEN @startDate AND @endDate";
                    }
                    appointmentTypesQuery += " GROUP BY at.AppointmentTypeName";
                    report.AppendLine("\nAppointment Types Summary:");
                    AppendQueryResults(report, connection, appointmentTypesQuery, filterByDate, startDate, endDate);

                    // Gender Breakdown for Patients
                    string genderPatientsQuery = "SELECT Gender, COUNT(*) AS Count FROM tblPatient GROUP BY Gender";
                    report.AppendLine("\nGender Breakdown for Patients:");
                    AppendQueryResults(report, connection, genderPatientsQuery);

                    // Gender Breakdown for Staff
                    string genderStaffQuery = "SELECT Gender, COUNT(*) AS Count FROM tblStaff GROUP BY Gender";
                    report.AppendLine("\nGender Breakdown for Staff:");
                    AppendQueryResults(report, connection, genderStaffQuery);

                    // Staff Member with the Most Appointments
                    string topStaffQuery = @"
                SELECT s.FirstName + ' ' + s.LastName AS StaffName, COUNT(a.AppointmentID) AS AppointmentCount
                FROM tblAppointment a
                INNER JOIN tblStaff s ON a.StaffID = s.StaffID
                GROUP BY s.FirstName, s.LastName
                ORDER BY AppointmentCount DESC";
                    report.AppendLine("\nStaff Member with the Most Appointments:");
                    AppendQueryResults(report, connection, topStaffQuery, true);

                    rtxtReport.Text = report.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private int ExecuteScalarQuery(SqlConnection connection, string query, DateTime? startDate = null, DateTime? endDate = null)
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (startDate.HasValue && endDate.HasValue)
                {
                    command.Parameters.AddWithValue("@startDate", startDate.Value);
                    command.Parameters.AddWithValue("@endDate", endDate.Value);
                }
                return (int)command.ExecuteScalar();
            }
        }

        private void AppendQueryResults(StringBuilder report, SqlConnection connection, string query, bool filterByDate = false, DateTime? startDate = null, DateTime? endDate = null)
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (filterByDate && startDate.HasValue && endDate.HasValue)
                {
                    command.Parameters.AddWithValue("@startDate", startDate.Value);
                    command.Parameters.AddWithValue("@endDate", endDate.Value);
                }

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            report.AppendLine($"{reader.GetName(i)}: {reader[i]}");
                        }
                        report.AppendLine();
                    }
                }
            }
        }

        private void chkFilterDate_CheckedChanged(object sender, EventArgs e)
        {
            GenerateSummaryReport();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            GenerateSummaryReport();
        }
    }
}
