﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmStaffHome : Form
    {
        public frmStaffHome()
        {
            InitializeComponent();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logout successful, have a wonderful day!", "Logout successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Create an instance of Staff Login
            frmStaff Login = new frmStaff();

            // Show Home as a new window
            Login.Show();

            //Close Add Patient Form
            this.Close();

            //Reset StaffID Global Variable
            GlobalData.StaffID = -1;
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Reports
            frmReport Reports = new frmReport();

            // Show Home as a new window
            Reports.Show();

            //Close Add Patient Form
            this.Close();
        }

        private void databaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmDatabase Database = new frmDatabase();

            // Show Home as a new window
            Database.Show();

            //Close Add Patient Form
            this.Close();
        }

        private void appointmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Manage Appointment
            frmManageAppointment Appointment = new frmManageAppointment();

            // Show Manage Appointment as a new window
            Appointment.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void patientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Manage Patient
            frmManagePatient Patient = new frmManagePatient();

            // Show mANAGE patient as a new window
            Patient.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void appointmentTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Manage Appointment Type
            frmManageAppointmentType AppointType = new frmManageAppointmentType();

            // Show Manage Appointment Type as a new window
            AppointType.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of Manage Staff
            frmManageStaff Staff = new frmManageStaff();

            // Show Staff as a new window
            Staff.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void btnSetAppointment_Click(object sender, EventArgs e)
        {
            // Create an instance of Set Appointment
            frmSetAppointment Set = new frmSetAppointment();

            // Show Set Appointment as a new window
            Set.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void btnAddPatients_Click(object sender, EventArgs e)
        {
            // Create an instance of Add Patient
            frmAddPatient Add = new frmAddPatient();

            // Show Add Patient as a new window
            Add.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void btnAddStaff_Click(object sender, EventArgs e)
        {
            // Create an instance of Add Staff
            frmAddStaff Staff = new frmAddStaff();

            // Show Add Staff as a new window
            Staff.Show();

            //Close Staff Home Form
            this.Close();
        }

        private void btnAddAppType_Click(object sender, EventArgs e)
        {
            // Create an instance of Add Appointment Type
            frmAddAppointmentType AppointmentType = new frmAddAppointmentType();

            // Show Add Appointment Type as a new window
            AppointmentType.Show();

            //Close Staff Home Form
            this.Close();
        }
    }
}
