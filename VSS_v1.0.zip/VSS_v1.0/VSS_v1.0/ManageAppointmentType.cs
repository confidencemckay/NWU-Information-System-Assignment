﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmManageAppointmentType : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmManageAppointmentType()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            //Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            //Show Staff Home as a new window
            Home.Show();

            //Close Manage Appointment Type Form
            this.Close();
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(cmbAppointmentTypeName.Text))
            {
                MessageBox.Show("Appointment Type cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true; // Return true if all inputs are valid
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Enabling Input components for editing
            cmbAppointmentTypeName.Enabled = true;
            txtDescription.Enabled = true;

            MessageBox.Show("Update enabled. You may edit the appointment type record. Please don't forget to save changes.", "Editing enabled");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                if (MessageBox.Show("Do you want to save the changes?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string query = "UPDATE tblAppointmentType SET AppointmentTypeName = @AppointmentTypeName, Description = @Description WHERE AppointmentTypeID = @AppointmentTypeID";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@AppointmentTypeID", txtAppointTypeID.Text);
                            cmd.Parameters.AddWithValue("@AppointmentTypeName", cmbAppointmentTypeName.Text);
                            cmd.Parameters.AddWithValue("@Description", txtDescription.Text);

                            try
                            {
                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Appointment record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    //Disabling Input components for editing
                                    cmbAppointmentTypeName.Enabled = false;
                                    txtDescription.Enabled = false;

                                    //Reloading Database
                                    string qry = "SELECT * FROM tblAppointmentType";

                                    using (SqlConnection cnn = new SqlConnection(connectionString))
                                    {
                                        try
                                        {
                                            SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, cnn);
                                            DataTable dataTable = new DataTable();
                                            dataAdapter.Fill(dataTable);

                                            dbManageAppType.DataSource = dataTable;
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }

                                }
                                else
                                {
                                    MessageBox.Show("No records were updated.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            } //End-Validate Inputs If Statements
        }

        private void dbManageApp_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Load selected record into input components
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbManageAppType.Rows[e.RowIndex];

                txtAppointTypeID.Text = row.Cells["AppointmentTypeID"].Value.ToString();
                cmbAppointmentTypeName.Text = row.Cells["AppointmentTypeName"].Value.ToString();
                txtDescription.Text = row.Cells["Description"].Value.ToString();
            }
        }

        private void frmManageAppointmentType_Load(object sender, EventArgs e)
        {
            //Loading Database
            string query = "SELECT * FROM tblAppointmentType";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dbManageAppType.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            //Populating cmbAppointmentTypeName with appointment types from tblAppointmentType
            cmbAppointmentTypeName.Items.Clear();

            string qry = "SELECT DISTINCT AppointmentTypeName FROM tblAppointmentType";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(qry, connection))
                {
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                //Add the AppointmentTypeName to ComboBox
                                cmbAppointmentTypeName.Items.Add(reader["AppointmentTypeName"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading appointment types: " + ex.Message);
                    }
                }
            }

            //Delete function only for Admin
            if (GlobalData.StaffID != 1)
                btnDelete.Enabled = false;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Extract selected AppointmentTypeID 
            if (txtAppointTypeID.Text == null)
            {
                MessageBox.Show("Please select a appointment type to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedAppointTypeID = int.Parse(txtAppointTypeID.Text);

            //Confirm deletion
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this appointment type?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                string query = "DELETE FROM tblAppointmentType WHERE AppointmentTypeID = @AppointmentTypeID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AppointmentTypeID", selectedAppointTypeID);

                        try
                        {
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Appointment Type deleted successfully.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Reloading database
                                string qry = "SELECT * FROM tblAppointmentType";

                                using (SqlConnection cnn = new SqlConnection(connectionString))
                                {
                                    try
                                    {
                                        SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, cnn);
                                        DataTable dataTable = new DataTable();
                                        dataAdapter.Fill(dataTable);

                                        dbManageAppType.DataSource = dataTable;
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting appointment type: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
