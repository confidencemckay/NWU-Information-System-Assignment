﻿// CMPG223 - Group 46 - Confidence Makofane 42062748
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSS_v1._0
{
    public partial class frmManageStaff : Form
    {
        private string connectionString = "Data Source = DESKTOP-O2O2M8T;Database = VitalityCareSoftware; Integrated Security = true;";
        public frmManageStaff()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            // Create an instance of Staff Home
            frmStaffHome Home = new frmStaffHome();

            // Show Staff Home as a new window
            Home.Show();

            //Close Manage Appointment Type Form
            this.Close();
        }

        private void frmManageStaff_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM tblStaff";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dbManageStaff.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            //Delete function is only for the Admin
            if (GlobalData.StaffID != 1)
                btnDelete.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Enabling Input Controls for editing
            txtLastName.Enabled = true;
            txtFirstName.Enabled = true;
            txtPhoneNo.Enabled = true;
            txtIDNo.Enabled = true;
            txtEmail.Enabled = true;
            cmbGender.Enabled = true;
            txtPassword.Enabled = true;

            MessageBox.Show("Update enabled. You may edit the patient record. Please don't forget to save changes.", "Editing enabled", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("First Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFirstName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("LastName cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLastName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtIDNo.Text))
            {
                MessageBox.Show("ID Number cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIDNo.Focus();
                return false;
            }
            else if (txtIDNo.TextLength < 13)
            {
                MessageBox.Show("ID Number cannot be less than 13 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIDNo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPhoneNo.Text))
            {
                MessageBox.Show("Phone Number cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhoneNo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Email cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cmbGender.Text))
            {
                MessageBox.Show("Phone Number cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhoneNo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cmbGender.Text))
            {
                MessageBox.Show("Password cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhoneNo.Focus();
                return false;
            }

                return true; // Return true if all inputs are valid
        }
    

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                if (MessageBox.Show("Do you want to save the changes?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string query = "UPDATE tblStaff SET FirstName = @FirstName, LastName = @LastName, IDNumber = @IDNumber, PhoneNumber = @PhoneNumber, Email = @Email, Gender = @Gender, Password = @Password WHERE StaffID = @StaffID";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@StaffID", txtStaffID.Text);
                            cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                            cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                            cmd.Parameters.AddWithValue("@IDNumber", txtIDNo.Text);
                            cmd.Parameters.AddWithValue("@PhoneNumber", txtPhoneNo.Text);
                            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                            cmd.Parameters.AddWithValue("@Gender",cmbGender.Text);
                            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                            try
                            {
                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Appointment record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    //Disabling Input components for editing
                                    txtLastName.Enabled = false;
                                    txtFirstName.Enabled = false;
                                    txtPhoneNo.Enabled = false;
                                    txtIDNo.Enabled = false;
                                    txtEmail.Enabled = false;
                                    cmbGender.Enabled = false;
                                    txtPassword.Enabled = false;

                                    //Reloading the database
                                    string qry = "SELECT * FROM tblStaff";

                                    using (SqlConnection cnn = new SqlConnection(connectionString))
                                    {
                                        try
                                        {
                                            SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, cnn);
                                            DataTable dataTable = new DataTable();
                                            dataAdapter.Fill(dataTable);

                                            dbManageStaff.DataSource = dataTable;
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("No records were updated.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            } //End-Validate Inputs If Statements
        }

        private void dbManageStaff_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Load selected record into input components
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbManageStaff.Rows[e.RowIndex];

                txtStaffID.Text = row.Cells["StaffID"].Value.ToString();
                txtFirstName.Text = row.Cells["FirstName"].Value.ToString();
                txtLastName.Text = row.Cells["LastName"].Value.ToString();
                txtIDNo.Text = row.Cells["IDNumber"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();
                txtPhoneNo.Text = row.Cells["PhoneNumber"].Value.ToString();
                cmbGender.Text = row.Cells["Gender"].Value.ToString();
                txtPassword.Text = row.Cells["Password"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Extract selected StaffID 
            if (txtStaffID.Text == null)
            {
                MessageBox.Show("Please select a staff member to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedStaffID = int.Parse(txtStaffID.Text);

            //Confirm deletion
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this staff member?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                // SQL query to delete the staff member by StaffID
                string query = "DELETE FROM tblStaff WHERE StaffID = @StaffID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StaffID", selectedStaffID);

                        try
                        {
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Staff member deleted successfully.", "Deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Reloading database
                                string qry = "SELECT * FROM tblStaff";

                                using (SqlConnection cnn = new SqlConnection(connectionString))
                                {
                                    try
                                    {
                                        SqlDataAdapter dataAdapter = new SqlDataAdapter(qry, cnn);
                                        DataTable dataTable = new DataTable();
                                        dataAdapter.Fill(dataTable);

                                        dbManageStaff.DataSource = dataTable;
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("No staff member found with the selected ID.", "Deletion Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting staff member: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
