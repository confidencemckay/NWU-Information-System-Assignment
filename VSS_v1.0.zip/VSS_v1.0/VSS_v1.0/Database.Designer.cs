﻿namespace VSS_v1._0
{
    partial class frmDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDatabase));
            this.pnlDatabase = new System.Windows.Forms.Panel();
            this.cmbDatabase = new System.Windows.Forms.ComboBox();
            this.dbDatabase = new System.Windows.Forms.DataGridView();
            this.lblInstruct = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.pnlDatabase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbDatabase)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlDatabase
            // 
            this.pnlDatabase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDatabase.Controls.Add(this.cmbDatabase);
            this.pnlDatabase.Controls.Add(this.dbDatabase);
            this.pnlDatabase.Controls.Add(this.lblInstruct);
            this.pnlDatabase.Location = new System.Drawing.Point(95, 49);
            this.pnlDatabase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlDatabase.Name = "pnlDatabase";
            this.pnlDatabase.Size = new System.Drawing.Size(1409, 708);
            this.pnlDatabase.TabIndex = 3;
            // 
            // cmbDatabase
            // 
            this.cmbDatabase.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDatabase.FormattingEnabled = true;
            this.cmbDatabase.Items.AddRange(new object[] {
            "Appointments",
            "Appointment Type",
            "Patients",
            "Staff"});
            this.cmbDatabase.Location = new System.Drawing.Point(319, 14);
            this.cmbDatabase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbDatabase.Name = "cmbDatabase";
            this.cmbDatabase.Size = new System.Drawing.Size(265, 28);
            this.cmbDatabase.TabIndex = 6;
            this.cmbDatabase.SelectedIndexChanged += new System.EventHandler(this.cmbDatabase_SelectedIndexChanged);
            // 
            // dbDatabase
            // 
            this.dbDatabase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbDatabase.Location = new System.Drawing.Point(18, 60);
            this.dbDatabase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dbDatabase.Name = "dbDatabase";
            this.dbDatabase.Size = new System.Drawing.Size(1376, 622);
            this.dbDatabase.TabIndex = 4;
            // 
            // lblInstruct
            // 
            this.lblInstruct.AutoSize = true;
            this.lblInstruct.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruct.Location = new System.Drawing.Point(14, 17);
            this.lblInstruct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInstruct.Name = "lblInstruct";
            this.lblInstruct.Size = new System.Drawing.Size(233, 20);
            this.lblInstruct.TabIndex = 5;
            this.lblInstruct.Text = "Please select database table to view:";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(1510, 775);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 30);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Home";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // frmDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VSS_v1._0.Properties.Resources.pexels_jplenio_1103970;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1605, 817);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.pnlDatabase);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmDatabase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlDatabase.ResumeLayout(false);
            this.pnlDatabase.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbDatabase)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDatabase;
        private System.Windows.Forms.ComboBox cmbDatabase;
        private System.Windows.Forms.Label lblInstruct;
        private System.Windows.Forms.DataGridView dbDatabase;
        private System.Windows.Forms.Button btnSubmit;
    }
}